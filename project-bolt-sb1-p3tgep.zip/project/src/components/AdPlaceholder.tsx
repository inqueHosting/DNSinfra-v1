interface AdPlaceholderProps {
  width?: string;
  height?: string;
  position: string;
}

export default function AdPlaceholder({ width = "w-full", height = "h-24", position }: AdPlaceholderProps) {
  return (
    <div className={`${width} ${height} bg-gray-100/50 rounded border border-gray-200/50 flex items-center justify-center`}>
      <p className="text-sm text-gray-400">Ad Space ({position})</p>
    </div>
  );
}