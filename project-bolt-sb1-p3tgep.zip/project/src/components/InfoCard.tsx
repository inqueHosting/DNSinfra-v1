import { LucideIcon } from 'lucide-react';

interface InfoItem {
  label: string;
  value: string;
}

interface InfoCardProps {
  icon: LucideIcon;
  title: string;
  items: InfoItem[];
}

export default function InfoCard({ icon: Icon, title, items }: InfoCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon className="w-5 h-5 text-indigo-600" />
        <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
      </div>
      <dl className="space-y-2">
        {items.map((item) => (
          <div key={item.label} className="flex justify-between text-sm">
            <dt className="text-gray-500">{item.label}:</dt>
            <dd className="font-medium text-gray-900">{item.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}