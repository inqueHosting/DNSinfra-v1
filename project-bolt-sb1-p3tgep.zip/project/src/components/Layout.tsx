import { Link, Outlet } from 'react-router-dom';
import { Network } from 'lucide-react';

export default function Layout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <Link to="/" className="flex items-center">
                <Network className="h-6 w-6 text-indigo-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">DNSinfra</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/dns-lookup" className="text-sm font-medium text-gray-500 hover:text-gray-900">
                DNS Lookup
              </Link>
              <Link to="/ping" className="text-sm font-medium text-gray-500 hover:text-gray-900">
                Ping
              </Link>
              <Link to="/my-ip" className="text-sm font-medium text-gray-500 hover:text-gray-900">
                My IP
              </Link>
            </div>
          </div>
        </nav>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      <footer className="bg-white border-t mt-auto">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            © {new Date().getFullYear()} DNSinfra. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}