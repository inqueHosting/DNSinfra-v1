import AdPlaceholder from './AdPlaceholder';

export default function LoadingState() {
  return (
    <div className="animate-pulse space-y-6">
      <AdPlaceholder height="h-24" position="top" />
      
      <div className="flex gap-6">
        <div className="w-3/4 space-y-6">
          <div className="h-32 bg-gray-100 rounded-lg" />
          <div className="grid grid-cols-2 gap-4">
            <div className="h-64 bg-gray-100 rounded-lg" />
            <div className="h-64 bg-gray-100 rounded-lg" />
          </div>
        </div>
        <div className="w-1/4">
          <div className="h-[600px] bg-gray-100 rounded-lg" />
        </div>
      </div>
    </div>
  );
}