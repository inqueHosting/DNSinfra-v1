import { LucideIcon } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ToolCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  to: string;
}

export default function ToolCard({ title, description, icon: Icon, to }: ToolCardProps) {
  return (
    <Link
      to={to}
      className="group flex items-start p-4 bg-white rounded-lg border border-gray-100 hover:border-indigo-100 hover:shadow-sm transition-all"
    >
      <div className="shrink-0 p-2 bg-indigo-50 rounded-lg group-hover:bg-indigo-100 transition-colors">
        <Icon className="w-5 h-5 text-indigo-600" />
      </div>
      <div className="ml-4">
        <h3 className="text-sm font-medium text-gray-900">{title}</h3>
        <p className="mt-1 text-xs text-gray-500">{description}</p>
      </div>
    </Link>
  );
}