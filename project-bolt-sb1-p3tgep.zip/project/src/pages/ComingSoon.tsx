import React from 'react';
import { useLocation } from 'react-router-dom';
import AdPlaceholder from '../components/AdPlaceholder';

export default function ComingSoon() {
  const location = useLocation();
  const toolName = location.pathname.slice(1).split('-').map(
    word => word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');

  return (
    <div className="space-y-8">
      <AdPlaceholder width="w-full" height="h-32" position="top" />
      
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">
          {toolName}
        </h1>
        <p className="mt-4 text-lg text-gray-600">
          This tool is coming soon! We're working hard to bring you the best network diagnostic tools.
        </p>
      </div>

      <AdPlaceholder width="w-full" height="h-32" position="bottom" />
    </div>
  );
}