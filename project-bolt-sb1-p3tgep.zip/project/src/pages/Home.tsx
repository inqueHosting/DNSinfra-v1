import React from 'react';
import ToolCard from '../components/ToolCard';
import AdPlaceholder from '../components/AdPlaceholder';
import {
  Search, Radio, Globe, Route, MapPin, Shield, Server, Database,
  Calculator, Hash, Globe2, ShieldCheck, FileCheck, Server2, Mail,
  Link2, FileKey, Key, FileSpreadsheet, FileLock2, FileKey2,
  Lock, KeyRound, FileText, Fingerprint, KeySquare,
  Gauge, Activity, BarChart3, Network, Scan, FileJson, FileCode,
  Link, FileSearch, ServerCog, Clock, Stethoscope, SplitSquareHorizontal,
  MailCheck
} from 'lucide-react';

interface ToolCategory {
  name: string;
  tools: {
    title: string;
    description: string;
    icon: any;
    to: string;
  }[];
}

export default function Home() {
  const categories: ToolCategory[] = [
    {
      name: "DNS & Network Tools",
      tools: [
        {
          title: 'DNS Lookup',
          description: 'Retrieve DNS records for any domain name',
          icon: Search,
          to: '/dns-lookup'
        },
        {
          title: 'Ping IPv4/IPv6',
          description: 'Test connectivity to any host',
          icon: Radio,
          to: '/ping'
        },
        {
          title: 'What Is My IP',
          description: 'View your public IP address and details',
          icon: Globe,
          to: '/my-ip'
        },
        {
          title: 'Traceroute',
          description: 'Visualize network path to destination',
          icon: Route,
          to: '/traceroute'
        },
        {
          title: 'Port Scanner',
          description: 'Check open ports on a target host',
          icon: Scan,
          to: '/port-scanner'
        },
        {
          title: 'Network Speed Test',
          description: 'Measure download/upload speeds',
          icon: Gauge,
          to: '/speed-test'
        }
      ]
    },
    {
      name: "Domain & DNS Management",
      tools: [
        {
          title: 'DNS Propagation',
          description: 'Check DNS propagation globally',
          icon: Globe2,
          to: '/dns-propagation'
        },
        {
          title: 'Reverse DNS',
          description: 'Perform reverse DNS lookups',
          icon: Link2,
          to: '/reverse-dns'
        },
        {
          title: 'Domain Health',
          description: 'Comprehensive domain health check',
          icon: Stethoscope,
          to: '/domain-health'
        },
        {
          title: 'Domain Age',
          description: 'Check domain registration age',
          icon: Clock,
          to: '/domain-age'
        },
        {
          title: 'Domain Compare',
          description: 'Compare DNS settings between domains',
          icon: SplitSquareHorizontal,
          to: '/domain-compare'
        },
        {
          title: 'Domain Email Config',
          description: 'Verify email-related DNS records',
          icon: MailCheck,
          to: '/email-config'
        }
      ]
    },
    {
      name: "Security Tools",
      tools: [
        {
          title: 'SSL Validator',
          description: 'Validate SSL certificates',
          icon: ShieldCheck,
          to: '/ssl-validator'
        },
        {
          title: 'HTTP Headers',
          description: 'Analyze security headers',
          icon: Shield,
          to: '/http-headers'
        },
        {
          title: 'Password Strength',
          description: 'Test password security',
          icon: Lock,
          to: '/password-strength'
        },
        {
          title: 'Hash Generator',
          description: 'Generate various hash types',
          icon: Hash,
          to: '/hash-generator'
        },
        {
          title: 'Certificate Decoder',
          description: 'Decode SSL certificates',
          icon: FileKey,
          to: '/cert-decoder'
        },
        {
          title: 'CSR Decoder',
          description: 'Decode Certificate Signing Requests',
          icon: FileKey2,
          to: '/csr-decoder'
        }
      ]
    },
    {
      name: "Developer Tools",
      tools: [
        {
          title: 'JSON Formatter',
          description: 'Format and validate JSON data',
          icon: FileJson,
          to: '/json-formatter'
        },
        {
          title: 'Base64 Tool',
          description: 'Encode/decode Base64 data',
          icon: FileCode,
          to: '/base64'
        },
        {
          title: 'URL Parser',
          description: 'Parse and construct URLs',
          icon: Link,
          to: '/url-parser'
        },
        {
          title: 'HTTP Status',
          description: 'Test HTTP response codes',
          icon: FileSearch,
          to: '/http-status'
        },
        {
          title: 'API Tester',
          description: 'Test API endpoints',
          icon: ServerCog,
          to: '/api-tester'
        }
      ]
    },
    {
      name: "IP & Network Analysis",
      tools: [
        {
          title: 'IP Location',
          description: 'Find geographical location of any IP',
          icon: MapPin,
          to: '/ip-location'
        },
        {
          title: 'IP Blacklist',
          description: 'Check if an IP is blacklisted',
          icon: Shield,
          to: '/ip-blacklist'
        },
        {
          title: 'IP WHOIS',
          description: 'Perform WHOIS lookups',
          icon: Database,
          to: '/ip-whois'
        },
        {
          title: 'Subnet Calculator',
          description: 'Calculate IP subnets',
          icon: Calculator,
          to: '/subnet-calc'
        },
        {
          title: 'IPv4 Generator',
          description: 'Generate IPv4 address ranges',
          icon: Server,
          to: '/ipv4-generator'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl">
            Professional DNS & Network Tools
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive suite of network diagnostic and security tools
          </p>
        </div>

        <AdPlaceholder width="w-full" height="h-32" position="top" />

        {categories.map((category, index) => (
          <div key={category.name} className="space-y-6">
            <div className="flex items-center">
              <h2 className="text-2xl font-bold text-gray-900">{category.name}</h2>
              <div className="ml-4 flex-1 border-t border-gray-200" />
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {category.tools.map((tool) => (
                <ToolCard key={tool.to} {...tool} />
              ))}
            </div>

            {index < categories.length - 1 && (
              <AdPlaceholder width="w-full" height="h-24" position={`category-${index}`} />
            )}
          </div>
        ))}

        <AdPlaceholder width="w-full" height="h-32" position="bottom" />
      </div>
    </div>
  );
}