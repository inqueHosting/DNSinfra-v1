import { useEffect, useState } from 'react';
import { MapPin, Network, Globe, Server, RefreshCw } from 'lucide-react';
import AdPlaceholder from '../components/AdPlaceholder';
import InfoCard from '../components/InfoCard';
import { fetchIpInfo, type IpInfo } from '../services/ipService';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';

export default function MyIp() {
  const [ipInfo, setIpInfo] = useState<IpInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchIpInfo();
      setIpInfo(data);
    } catch (err) {
      setError('Unable to retrieve IP information. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) return <LoadingState />;
  if (error) {
    return (
      <div className="space-y-6">
        <ErrorState message={error} />
        <div className="flex justify-center">
          <button
            onClick={fetchData}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <RefreshCw className="w-4 h-4" />
            Try Again
          </button>
        </div>
      </div>
    );
  }
  if (!ipInfo) return null;

  return (
    <div className="space-y-6">
      <AdPlaceholder height="h-24" position="top" />
      
      <div className="flex gap-6">
        <div className="w-3/4 space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Your IP Address</h1>
                <p className="text-sm text-gray-500 mt-1">IPv{ipInfo.version} Address</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-mono text-indigo-600">{ipInfo.ip}</div>
                <div className="text-sm text-gray-500 mt-1">{ipInfo.network}</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <InfoCard
              icon={MapPin}
              title="Location Information"
              items={[
                { label: 'City', value: ipInfo.city || 'Unknown' },
                { label: 'Region', value: ipInfo.region || 'Unknown' },
                { label: 'Country', value: ipInfo.country || 'Unknown' },
                { label: 'Postal', value: ipInfo.postal || 'Unknown' },
                { label: 'Coordinates', value: `${ipInfo.latitude}, ${ipInfo.longitude}` }
              ]}
            />

            <InfoCard
              icon={Network}
              title="Network Details"
              items={[
                { label: 'ISP', value: ipInfo.org || 'Unknown' },
                { label: 'ASN', value: ipInfo.asn || 'Unknown' },
                { label: 'Network', value: ipInfo.network || 'Unknown' }
              ]}
            />

            <InfoCard
              icon={Globe}
              title="Additional Information"
              items={[
                { label: 'Timezone', value: ipInfo.timezone || 'Unknown' },
                { label: 'Hostname', value: ipInfo.hostname || 'Unknown' }
              ]}
            />

            <InfoCard
              icon={Server}
              title="Technical Details"
              items={[
                { label: 'IP Version', value: `IPv${ipInfo.version}` },
                { label: 'CIDR', value: ipInfo.network || 'Unknown' }
              ]}
            />
          </div>

          <AdPlaceholder height="h-24" position="bottom" />
        </div>

        <div className="w-1/4">
          <AdPlaceholder width="w-full" height="h-[600px]" position="sidebar" />
        </div>
      </div>
    </div>
  );
}