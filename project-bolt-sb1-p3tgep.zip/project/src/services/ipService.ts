import axios from 'axios';

export interface IpInfo {
  ip: string;
  network: string;
  version: string;
  city: string;
  region: string;
  country: string;
  latitude: number;
  longitude: number;
  org: string;
  postal: string;
  timezone: string;
  asn: string;
  hostname: string;
}

export async function fetchIpInfo(): Promise<IpInfo> {
  try {
    // First get the IP address
    const ipResponse = await axios.get('https://api.ipify.org?format=json');
    const ip = ipResponse.data.ip;

    // Then get detailed information
    const detailsResponse = await axios.get(`https://ipapi.com/ip_api.php?ip=${ip}`);
    const data = detailsResponse.data;
    
    return {
      ip: ip,
      network: `${ip}/24`,
      version: ip.includes(':') ? '6' : '4',
      city: data.city || '',
      region: data.region || '',
      country: data.country_name || '',
      latitude: data.latitude || 0,
      longitude: data.longitude || 0,
      org: data.org || '',
      postal: data.postal || '',
      timezone: data.timezone || '',
      asn: data.asn || '',
      hostname: data.hostname || ''
    };
  } catch (error) {
    // Fallback to ip-api.com if the primary source fails
    try {
      const fallbackResponse = await axios.get('http://ip-api.com/json');
      const details = fallbackResponse.data;
      
      return {
        ip: details.query,
        network: `${details.query}/24`,
        version: details.query.includes(':') ? '6' : '4',
        city: details.city || '',
        region: details.regionName || '',
        country: details.country || '',
        latitude: details.lat || 0,
        longitude: details.lon || 0,
        org: details.isp || '',
        postal: details.zip || '',
        timezone: details.timezone || '',
        asn: details.as || '',
        hostname: ''
      };
    } catch (fallbackError) {
      // Final fallback to just show IP address if everything else fails
      try {
        const basicResponse = await axios.get('https://api.ipify.org?format=json');
        const basicIp = basicResponse.data.ip;
        
        return {
          ip: basicIp,
          network: `${basicIp}/24`,
          version: basicIp.includes(':') ? '6' : '4',
          city: '',
          region: '',
          country: '',
          latitude: 0,
          longitude: 0,
          org: '',
          postal: '',
          timezone: '',
          asn: '',
          hostname: ''
        };
      } catch (finalError) {
        throw new Error('Failed to fetch IP information from all available sources');
      }
    }
  }
}